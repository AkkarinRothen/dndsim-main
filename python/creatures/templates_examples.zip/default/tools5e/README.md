---
type: fileIndex
---
# 5eTools default templates

This directory contains the default templates for 5eTools data.

- [`background`](./background2md.txt)
- [`bastion`](./bastion2md.txt)
- [`class`](./class2md.txt)
- [`css-font`](./css-font.txt)
- [`deck`](./deck2md.txt)
- [`deity`](./deity2md.txt)
- [`feat`](./feat2md.txt)
- [`hazard`](./hazard2md.txt)
- [`index`](./index.txt)
- [`item`](./item2md.txt)
- [`monster`](./monster2md.txt)
- [`note`](./note2md.txt)
- [`object`](./object2md.txt)
- [`psionic`](./psionic2md.txt)
- [`race`](./race2md.txt)
- [`reward`](./reward2md.txt)
- [`spell`](./spell2md.txt)
- [`subclass`](./subclass2md.txt)
- [`vehicle`](./vehicle2md.txt)
