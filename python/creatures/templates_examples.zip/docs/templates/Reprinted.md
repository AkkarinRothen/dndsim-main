# Reprinted

A simple record to hold the name and source of a reprinted item.

## Attributes

[name](#name), [source](#source)

### name

Name of the reprinted item

### source

Primary source of the reprinted item
