# QuteRitualChecks

Pf2eTools ritual check attributes

This data object provides a default mechanism for creating
a marked up string based on the attributes that are present.
To use it, reference it directly: `{resource.checks}`.

## Attributes

[primaryChecks](#primarychecks), [secondaryChecks](#secondarychecks)

### primaryChecks

Formatted string. Links to skills for primary checks

### secondaryChecks

Formatted string. Links to skills for secondary checks
