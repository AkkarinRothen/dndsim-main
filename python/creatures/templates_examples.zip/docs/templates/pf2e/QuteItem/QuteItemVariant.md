# QuteItemVariant

Pf2eTools item variant attributes

This data object provides a default mechanism for creating
a marked up string based on the attributes that are present.

To use it, reference it directly:

```md
{#for variants in resource.variants}
{variants}
{/for}
```

or, using `{#each}` instead:

```md
{#each resource.variants}
{it}
{/each}
```

## Attributes

[craftReq](#craftreq), [entries](#entries), [level](#level), [price](#price), [variantType](#varianttype)

### craftReq


### entries


### level


### price


### variantType
