# QuteAffliction

Pf2eTools Affliction attributes (inline/embedded, `inline-affliction2md.txt`)

Extension of [Pf2eQuteNote](../Pf2eQuteNote.md)

## Attributes

[altNames](#altnames), [books](#books), [category](#category), [effect](#effect), [getAliases](#getaliases), [hasSections](#hassections), [isEmbedded](#isembedded), [labeledSource](#labeledsource), [level](#level), [maxDuration](#maxduration), [name](#name), [notes](#notes), [onset](#onset), [reprintOf](#reprintof), [savingThrow](#savingthrow), [source](#source), [sourceAndPage](#sourceandpage), [sourcesWithFootnote](#sourceswithfootnote), [stages](#stages), [tags](#tags), [temptedCurse](#temptedcurse), [text](#text), [traits](#traits), [vaultPath](#vaultpath)

### altNames


### books

List of source books using abbreviated name. Fantasy statblocks uses this list format, as an example.

### category

Category of affliction (Curse or Disease). Usually shown alongside the level.

### effect

Formatted text. Affliction effect, may be multiple lines.

### getAliases

Aliases for this note, including the note name, as quoted/escaped strings.

Example values:
- "+1 All-Purpose Tool"
- "Carl \"The Elder\" Frost"

In templates:
```md
aliases:
{#each resource.aliases}
- {it}
{/each}
```

### hasSections

True if the content (text) contains sections

### isEmbedded

If true, then this affliction is embedded into a larger note.

### labeledSource

Formatted string describing the content's source(s): `_Source: <sources>_`

### level

Integer from 1 to 10. Level of the affliction.

### maxDuration

Formatted text. Maximum duration of the infliction.

### name

Note name

### notes

Any additional notes associated with the affliction.

### onset

Formatted text. Maximum duration of the infliction.

### reprintOf

List of content superceded by this note (as [Reprinted](../../Reprinted.md))

### savingThrow

The saving throw required to not contract or advance the affliction as
[QuteAfflictionSave](QuteAfflictionSave.md)

### source

String describing the content's source(s)

### sourceAndPage

Book sources as list of [SourceAndPage](../../SourceAndPage.md)

### sourcesWithFootnote

Get Sources as a footnote.

Calling this method will return an italicised string with the primary source
followed by a footnote listing all other sources. Useful for types
that tend to have many sources.

### stages

Affliction stages: map of name to stage data as
[QuteAfflictionStage](QuteAfflictionStage.md)

### tags

Collected tags for inclusion in frontmatter

### temptedCurse

A description of the tempted version of the curse

### text

Formatted text. For most templates, this is the bulk of the content.

### traits

Collection of traits (decorated links)

### vaultPath

Path to this note in the vault
