# QuteAfflictionStage

Pf2eTools affliction stage attributes.

## Attributes

[duration](#duration), [text](#text)

### duration

Formatted text. Affliction duration

### text

Formatted text. Affliction stage
