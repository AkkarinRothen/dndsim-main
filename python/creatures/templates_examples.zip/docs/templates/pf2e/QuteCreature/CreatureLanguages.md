# CreatureLanguages

The languages and language features known by a creature. Example default output:
`Common, Sylvan; telepathy 100ft; knows any language the summoner does`

## Attributes

[abilities](#abilities), [languages](#languages), [notes](#notes)

### abilities

Language-related abilities (optional)

### languages

Languages known (optional)

### notes

Language-related notes (optional)
