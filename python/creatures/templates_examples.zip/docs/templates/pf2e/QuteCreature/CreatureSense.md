# CreatureSense

A creature's senses. Example default output: `tremorsense (imprecise) 20ft`

## Attributes

[name](#name), [range](#range), [type](#type)

### name

The name of the sense (required, string)

### range

The range of the sense (optional, integer)

### type

The type of the sense - e.g. precise, imprecise (optional, string)
