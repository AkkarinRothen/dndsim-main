# DurationUnit

Represents different units that a duration might be in.

## Attributes
