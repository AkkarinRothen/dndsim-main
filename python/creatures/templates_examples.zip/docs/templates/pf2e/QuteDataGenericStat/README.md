# QuteDataGenericStat

A generic container for a PF2e stat value which may have an attached note.

## Attributes
