# SimpleStat

A basic [QuteDataGenericStat](README.md) which provides
only a value and possibly a note.

Default representation: `10 (some note) (some other note)`

## Attributes
