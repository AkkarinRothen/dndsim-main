# QuteDataSpeed

Examples:

- `10 feet, swim 20 feet (some note); some ability`
- `10 feet, swim 20 feet, some ability`

## Attributes

[abilities](#abilities), [notes](#notes), [otherSpeeds](#otherspeeds), [value](#value)

### abilities

Any speed-related abilities

### notes

Any speed-related notes

### otherSpeeds

Other speeds, as a map of (name, speed in feet)

### value

The land speed in feet
