# QuteSpellAmp

Pf2eTools spell Amp attributes

This attribute will render itself as labeled elements
if you reference it directly: `{resource.amp}`.

## Attributes

[ampEffects](#ampeffects), [text](#text)

### ampEffects

Heightened amp effects as a list of [Traits](../../NamedText.md)

### text

Formatted text describing amp effects
