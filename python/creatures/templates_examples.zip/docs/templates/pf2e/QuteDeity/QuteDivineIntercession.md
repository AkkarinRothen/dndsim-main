# QuteDivineIntercession

Pf2eTools divine intercession attributes.

This data object provides a default mechanism for creating
a marked up string based on the attributes that are present.
To use it, reference it directly: `{resource.actionType}`.

## Attributes

[flavor](#flavor), [majorBoon](#majorboon), [majorCurse](#majorcurse), [minorBoon](#minorboon), [minorCurse](#minorcurse), [moderateBoon](#moderateboon), [moderateCurse](#moderatecurse), [source](#source)

### flavor


### majorBoon


### majorCurse


### minorBoon


### minorCurse


### moderateBoon


### moderateCurse


### source
