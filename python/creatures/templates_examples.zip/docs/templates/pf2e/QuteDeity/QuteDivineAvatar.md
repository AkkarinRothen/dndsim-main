# QuteDivineAvatar

Pf2eTools avatar attributes

This data object provides a default mechanism for creating
a marked up string based on the attributes that are present.
To use it, reference it directly: `{resource.actionType}`.

## Attributes

[abilities](#abilities), [ability](#ability), [attacks](#attacks), [name](#name), [preface](#preface), [shield](#shield), [speed](#speed)

### abilities


### ability


### attacks


### name


### preface


### shield


### speed

The avatar's speed, as a [QuteDataSpeed](../QuteDataSpeed.md)
