# TraitDescription

5eTools creature trait description.

## Attributes

[description](#description), [present](#present), [title](#title), [traits](#traits)

### description

Formatted text describing the collection of traits

### present


### title

Title of the trait description

### traits

Traits as a list of [NamedText](../../NamedText.md)
