# Initiative

5eTools creature initiative attributes.

## Attributes

[bonus](#bonus), [mode](#mode), [passive](#passive), [passiveInitiative](#passiveinitiative)

### bonus

Initiative modifier

### mode

Initiative mode: "advantage", "disadvantage", or "none"

### passive

Passive initiative value (number)

### passiveInitiative

String representation of passive initiative value
