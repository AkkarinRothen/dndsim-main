# InitiativeMode

Initiative mode: "advantage", "disadvantage", or "none"

## Attributes
