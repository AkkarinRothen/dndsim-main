# Spells

5eTools creature spell attributes (associated with a spell level)

## Attributes

[lowerBound](#lowerbound), [slots](#slots), [spells](#spells)

### lowerBound

Set if this represents a spell range (the associated key is the upper bound)

### slots

Available spell slots

### spells

List of spells (links)
