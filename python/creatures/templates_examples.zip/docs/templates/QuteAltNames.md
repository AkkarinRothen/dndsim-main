# QuteAltNames


## Attributes

[altNames](#altnames)

### altNames

Alternate names. (optional)
