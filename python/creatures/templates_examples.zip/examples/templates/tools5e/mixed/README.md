---
type: fileIndex
---
# Additional (mixed) templates

Additional examples that mash together optional elements from other examples.

- [`background`](mixed-background2md.txt),
- [`class`](mixed-class2md.txt),
- [`deck`](mixed-deck2md.txt),
- [`deity`](mixed-deity2md.txt),
- [`feat`](mixed-feat2md.txt),
- [`hazard`](mixed-hazard2md.txt),
- [`item`](mixed-item2md.txt),
- [`monster`](mixed-monster2md.txt),
- [`object`](mixed-object2md.txt),
- [`race`](mixed-race2md.txt),
- [`reward`](mixed-reward2md.txt),
- [`spell`](mixed-spell2md.txt),
- [`subclass`](mixed-subclass2md.txt),
- [`vehicle`](mixed-vehicle2md.txt)
